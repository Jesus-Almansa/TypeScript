import { Component } from '@angular/core';

@Component({
  selector: 'figura-triangulo',
  standalone: true,
  imports: [],
  templateUrl: './triangulo.component.html',
  styleUrl: './triangulo.component.css'
})
export class TrianguloComponent {

}
