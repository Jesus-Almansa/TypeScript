import { Component } from '@angular/core';
import { TrianguloComponent } from '../triangulo/triangulo.component';

@Component({
  selector: 'figura-cuadrado',
  standalone: true,
  imports: [],
  templateUrl: './cuadrado.component.html',
  styleUrl: './cuadrado.component.css'
})
export class CuadradoComponent {

}
