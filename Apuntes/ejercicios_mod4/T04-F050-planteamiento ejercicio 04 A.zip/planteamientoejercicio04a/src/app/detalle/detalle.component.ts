import { Component } from '@angular/core';

@Component({
  selector: 'cliente-detalle',
  standalone: true,
  imports: [],
  templateUrl: './detalle.component.html',
  styleUrl: './detalle.component.css'
})
export class DetalleComponent {

}
