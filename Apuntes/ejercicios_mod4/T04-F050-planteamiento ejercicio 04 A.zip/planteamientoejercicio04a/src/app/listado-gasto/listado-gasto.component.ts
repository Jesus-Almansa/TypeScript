import { Component } from '@angular/core';

@Component({
  selector: 'app-listado-gasto',
  standalone: true,
  imports: [],
  templateUrl: './listado-gasto.component.html',
  styleUrl: './listado-gasto.component.css'
})
export class ListadoGastoComponent {

}
