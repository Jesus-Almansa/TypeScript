import { Component } from '@angular/core';

@Component({
  selector: 'app-dos',
  standalone: true,
  imports: [],
  templateUrl: './dos.component.html',
  styleUrl: './dos.component.css'
})
export class DosComponent {

}
