import { Component } from '@angular/core';

@Component({
  selector: 'app-uno',
  standalone: true,
  imports: [],
  templateUrl: './uno.component.html',
  styleUrl: './uno.component.css'
})
export class UnoComponent {

}
