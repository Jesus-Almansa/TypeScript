import { Component } from '@angular/core';
import { Concepto } from '../models/concepto';
import { ConceptosService } from '../conceptos.service';

@Component({
  selector: 'app-conceptos',
  standalone: true,
  imports: [],
  templateUrl: './conceptos.component.html',
  styleUrl: './conceptos.component.css'
})
export class ConceptosComponent {
  conceptos:Concepto[]=[];

  constructor(private datosConceptos:ConceptosService){}

  ngOnInit() {
    this.conceptos=this.datosConceptos.getConceptos();
  }

  borrar(id:number) {
    this.datosConceptos.eliminarConcepto(id);
  }

  nuevo(cuadro:any) {
    let nombre=cuadro.value.trim();

    if (nombre.length>3) {
      this.datosConceptos.nuevoConcepto(nombre);
      cuadro.value='';
    }
  }
}
