import { Injectable } from '@angular/core';
import { Concepto } from './models/concepto';

@Injectable({
  providedIn: 'root'
})
export class ConceptosService {
  private conceptos:Concepto[];
  private ultimoId:number;

  //Somos pobres y no tenemos un servidor de verdad...
  constructor() {
    this.conceptos=[
      new Concepto(10,"Kilometraje"),
      new Concepto(20,"Dieta comida"),
      new Concepto(30,"Dieta cena"),
      new Concepto(40,"Dieta alojamiento"),
    ];
    //Chapucillas. No hay una base de datos de verdad.
    this.ultimoId=40;
  }

  getConceptos() {
    return this.conceptos;
  }

  nuevoConcepto(nombre:string) {
    this.ultimoId+=10;
    this.conceptos.push(new Concepto(this.ultimoId, nombre));
  }

  eliminarConcepto(id:number) {
    for (let i=0; i <=this.conceptos.length; i++) {
      if (this.conceptos[i].idConcepto==id) {
        this.conceptos.splice(i,1);
        return true;
      }
    }
    
    return false;
  }

  buscarNombreConcepto(id:number) {
    for (let c of this.conceptos)
      if (c.idConcepto==id) return c.nombre;
      
    return 'Desconocido';
  }
}
