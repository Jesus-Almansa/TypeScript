import { Injectable } from '@angular/core';
import { Gasto } from './models/gasto';

@Injectable({
  providedIn: 'root'
})
export class GastosService {
  private gastos:Gasto[];
  private ultimoId:number;

  //Somos pobres y no tenemos un servidor de verdad...
  constructor() {
    this.gastos=[
      new Gasto(100,10, 120,34),
      new Gasto(200,20,2,9.90),
      new Gasto(300,40,2,56)
    ];
    //Chapucillas. No hay una base de datos de verdad.
    this.ultimoId=300;
  }

  getGastos() {
    return this.gastos;
  }

  nuevoGasto(idConcepto:number, cantidad:number, precio:number) {
    this.ultimoId+=10;
    this.gastos.push(new Gasto(this.ultimoId, idConcepto, cantidad, precio));
  }

  eliminarGasto(id:number) {
    for (let i=0; i <=this.gastos.length; i++) {
      if (this.gastos[i].idGasto==id) {
        this.gastos.splice(i,1);
        return true;
      }
    }
    
    return false;
  }
}
