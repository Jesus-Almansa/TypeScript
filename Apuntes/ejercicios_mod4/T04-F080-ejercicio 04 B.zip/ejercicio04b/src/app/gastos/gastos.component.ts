import { Component } from '@angular/core';
import { Gasto } from '../models/gasto';
import { GastosService } from '../gastos.service';
import { ConceptosService } from '../conceptos.service';
import { FormsModule } from '@angular/forms';
import { Concepto } from '../models/concepto';

@Component({
  selector: 'app-gastos',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './gastos.component.html',
  styleUrl: './gastos.component.css'
})
export class GastosComponent {
  gastos:Gasto[]=[];
  conceptos:Concepto[]=[];

  codigoConcepto='';
  cantidad='';
  precio='';

  constructor(private datosGastos:GastosService, 
              private datosConceptos:ConceptosService){}

  ngOnInit() {
    this.gastos=this.datosGastos.getGastos();
    this.conceptos=this.datosConceptos.getConceptos();
  }

  borrar(id:number) {
    console.log(id);
    
    this.datosGastos.eliminarGasto(id);
  }

  buscarNombreConcepto(idConcepto:number) {
    return this.datosConceptos.buscarNombreConcepto(idConcepto);
  }

  nuevo() {
    let valorCodigoConcepto=Number(this.codigoConcepto);
    let valorCantidad=Number(this.cantidad);
    let valorPrecio=Number(this.precio);

    //la "validación" que he aplicado es lamentable. Volveremos a ello en el tema dedicado a formularios
    if (isNaN(valorCantidad) || isNaN(valorCodigoConcepto) || isNaN(valorPrecio)) return;
    if (valorCantidad==0 || valorCodigoConcepto==0 || valorPrecio==0) return;

    this.datosGastos.nuevoGasto(valorCodigoConcepto, valorCantidad, valorPrecio);
    this.codigoConcepto='';
    this.cantidad='';
    this.precio='';
  }

}
