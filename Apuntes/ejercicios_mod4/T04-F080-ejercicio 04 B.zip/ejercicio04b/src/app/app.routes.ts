import { Routes } from '@angular/router';
import { ConceptosComponent } from './conceptos/conceptos.component';
import { GastosComponent } from './gastos/gastos.component';

export const routes: Routes = [
    {path:'conceptos',component:ConceptosComponent},
    {path:'gastos',component:GastosComponent},
    {path:'',component:ConceptosComponent},
];
