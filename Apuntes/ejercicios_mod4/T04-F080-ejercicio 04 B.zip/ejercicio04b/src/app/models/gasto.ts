export class Gasto {
    constructor(
        public idGasto:number,
        public idConcepto:number,
        public cantidad:number,
        public precio:number
    ) {}
}

