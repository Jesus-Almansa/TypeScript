export class Concepto {
    constructor(
        public idConcepto:number,
        public nombre:string
    ){}
}

