import { CommonModule, registerLocaleData } from '@angular/common';
import { Component } from '@angular/core';
import { Cliente } from '../models/cliente';
import es from '@angular/common/locales/es';
import { DatosService } from '../datos.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-listado-gasto',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './listado-gasto.component.html',
  styleUrl: './listado-gasto.component.css',
  providers:[DatosService]
})
export class ListadoGastoComponent {
  lista:Cliente[]=[];
  filtroOrigen='';
  //SIEMPRE recibes un texto de los controles de formulario, lo definas como lo definas
  minimo='';
  maximo='';

  constructor(private datos:DatosService){}

  ngOnInit() {
    registerLocaleData(es);
    this.lista=this.datos.getTodosLosDatos();
  }

  aplicarFiltro() {
    //Y fíjate como convierto CORRECTAMENTE textos a números. NO ES IGUAL QUE EN JAVASCRIPT
    let valorMin=Number(this.minimo);
    let valorMax=Number(this.maximo);

    /* Los errores sintácticos (textos o números mal escritos, valores obviamente absurdos, etc.) son problema
    DEL COMPONENTE. Es aquí donde compruebo si los límites son cifras en vez de textos o si el mínimo es menor
    que el máximo. Ese tipo de fallos absurdos NUNCA deben llegar al servicio: la presentación no es cosa suya */

    //Uso MIN_VALUE y MAX_VALUE para hacer bonito. Vale cualquier cosa por debajo o por encima de los valores posibles
    //OJO! isNaN() SÓLO devuelve "true" si el valor numérico es EXACTAMENTE "NaN"
    if (Number.isNaN(valorMin) || this.minimo=='') valorMin=Number.MIN_VALUE ;
    if (Number.isNaN(valorMax) || this.maximo=='') valorMax=Number.MAX_VALUE ;

    if (valorMax<valorMin) {
      const temp=valorMax;
      valorMax=valorMin;
      valorMin=temp;

      if (valorMin==Number.MIN_VALUE) this.minimo='';
      else this.minimo=valorMin.toString();

      if (valorMax==Number.MAX_VALUE) this.maximo='';
      else this.maximo=valorMax.toString();
    }

    this.lista=this.datos.getPorRangodeGastoMedio(valorMin, valorMax);
  }

  
ejemploConversion() {
  let unTexto='123';
  let elValor=Number(unTexto);
  //esta función SÓLO comprueba si el número vale "NaN"
  if (Number.isNaN(elValor)) console.log('El texto no era una cifra');
  else console.log('Se ha convertido correctamente');
  
  
}

}
