import { Component } from '@angular/core';
import { Cliente } from '../models/cliente';
import { DatosService } from '../datos.service';
import { CommonModule, registerLocaleData } from '@angular/common';
import es from '@angular/common/locales/es';

@Component({
  selector: 'cliente-detalle',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detalle.component.html',
  styleUrl: './detalle.component.css',
  providers:[DatosService]
})
export class DetalleComponent {

  /*En este ejemplo será el componente quien se encargue de la "navegación". Pedirá los datos 
  una vez al servicio y a partir de ahí se encargará de presentarlos como quiera. ¿Eso es correcto?
  Pues depende del caso. Si sabes que los datos no suelen cambiar, molestar al servicio (al servidor)
  sólo una vez será muy rápido. Si hay muchos datos o cambian con frecuencia, será un desastre */
  private clientes:Cliente[]=[];

  /* Debería haberlo iniciado así:
    clienteActual:Cliente | null=null;
  Sé que voy a iniciarlo en el ngOnInit(), por lo que me puedo permitir el lujo
  de decirle al compilador que me deje en paz. Pero no es tan simple... Lo voy a 
  iniciar con lo que me devuelva el servicio, y tal vez el servicio me diga que no 
  hay datos! En este ejemplo en el que los clientes me los invento no va a suceder,
  pero sí que puede pasar en la vida real */
  clienteActual !: Cliente;
  indiceActual=0;

  constructor(private datos:DatosService){}

  ngOnInit() {
    registerLocaleData(es);
    this.clientes=this.datos.getTodosLosDatos();
    this.indiceActual=0;
    this.clienteActual=this.clientes[this.indiceActual];
  }

  cantidad() {
    return this.clientes.length;
  }

  siguiente() {
    this.indiceActual++;
    if (this.indiceActual>=this.clientes.length) this.indiceActual=0;
    this.clienteActual=this.clientes[this.indiceActual];
  }

  anterior() {
    this.indiceActual--;
    if (this.indiceActual<0) this.indiceActual=this.clientes.length-1;
    this.clienteActual=this.clientes[this.indiceActual];
  }
}
