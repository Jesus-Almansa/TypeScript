import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EjemploBindingComponent } from './ejemplo-binding/ejemplo-binding.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, EjemploBindingComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ejemplo04';
}
