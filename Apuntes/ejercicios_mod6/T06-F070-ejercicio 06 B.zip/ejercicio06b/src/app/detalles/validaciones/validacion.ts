import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export class Validacion {
    static fechamin(fecha:string): ValidatorFn {
        return (control:AbstractControl): ValidationErrors | null => {
            if (control.value==null) return null;

            const fechaControl=Date.parse(control.value);
            if (isNaN(fechaControl)) return null;

            const fechaMin=Date.parse(fecha);
            if (isNaN(fechaMin)) return null;

            if (fechaMin <= fechaControl) return null;

            return {'fechamin': {'fechamin': fecha, 'actual': control.value}};
        }
    }

    static mayusculas(aceptaEspacios:boolean):ValidatorFn {
        return (control:AbstractControl): ValidationErrors | null => {
            if (control.value==null) return null;
            if (!aceptaEspacios && control.value.indexOf(' ')!==-1)
                return {'mayusculas': {'mayusculas': 'hay espacios', 'actual': control.value}};
            if (/^[A-ZÑÁÉÍÓÚÜ]+$/.test(control.value)) return null;
            return {'mayusculas': {'mayusculas': 'no son mayúsculas', 'actual': control.value}};
        }
    }
}