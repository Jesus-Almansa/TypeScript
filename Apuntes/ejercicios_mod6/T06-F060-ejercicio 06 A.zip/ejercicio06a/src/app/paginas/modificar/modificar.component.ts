import { Component, OnInit, inject, signal } from '@angular/core';
import { DesplegableComponent } from '../../detalles/desplegable/desplegable.component';
import { PantallaComponent } from '../../detalles/pantalla/pantalla.component';
import { Producto } from '../../modelo/producto';
import { DatosService } from '../../datos.service';

@Component({
  selector: 'app-modificar',
  standalone: true,
  imports: [DesplegableComponent, PantallaComponent],
  templateUrl: './modificar.component.html',
  styleUrls: ['./modificar.component.css','../estilos/maquetacion.css']
})
export class ModificarComponent implements OnInit{

  private datos=inject(DatosService);
  bien=signal(false);
  mal=signal(false);
  lista=signal<Producto[]>([]);
  producto=signal(new Producto(null,null,null,null));

  ngOnInit(): void {
    this.lista.set(this.datos.leerTodos());
  }

  datosRecibidos(referencia:string) {
    if (referencia==null) return;

    let encontrado=this.datos.leer(referencia);
    if (encontrado!=null) this.producto.set(encontrado);
    
  }

  productoCambiado(p:Producto) {
    if (this.datos.modificar(p)) {
      this.bien.set(true);
      this.mal.set(false);
    }
    else {
      this.bien.set(false);
      this.mal.set(true);
    }
  }
}