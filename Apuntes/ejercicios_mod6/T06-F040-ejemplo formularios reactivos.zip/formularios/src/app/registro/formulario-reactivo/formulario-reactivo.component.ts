import { Component, inject} from '@angular/core';
import { Registro, Tipo } from '../models/registro';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { DatosService } from '../datos.service';

@Component({
  selector: 'app-formulario-reactivo',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './formulario-reactivo.component.html',
  styleUrls: ['./formulario-reactivo.component.css', '../estilos/formulario.css']
})
export class FormularioReactivoComponent  {
  
  valoresTipo:string[]=Object.values(Tipo);
  datos=inject(DatosService);

  formulario=new FormGroup({
    identificador:new FormControl(''),
    nombre:new FormControl(''),
    apellidos:new FormControl(''),
    correo:new FormControl(''),
    fecha:new FormControl(new Date().toISOString().split('T')[0]),
    salario:new FormControl(''),
    tipo:new FormControl('D')
  });

  traducirTipo(valor:string):Tipo {
    if (valor=='E') return Tipo.EXPERTO;
    if (valor=='M') return Tipo.MEDIO;
    if (valor=='P') return Tipo.PRINCIPIANTE;
    return Tipo.DESCONOCIDO;
  }

  enviarDatos() {
    let r=new Registro(
      this.formulario.value.identificador==null?null:Number.parseInt(this.formulario.value.identificador),
      this.formulario.value.nombre || null,
      this.formulario.value.apellidos || null,
      this.formulario.value.correo || null,
      new Date(this.formulario.value.fecha || ''),
      this.formulario.value.salario==null?null:Number.parseFloat(this.formulario.value.salario),
      this.traducirTipo(this.formulario.value.tipo || 'D')
    );

    this.datos.addRegistro(r);
  }

}



