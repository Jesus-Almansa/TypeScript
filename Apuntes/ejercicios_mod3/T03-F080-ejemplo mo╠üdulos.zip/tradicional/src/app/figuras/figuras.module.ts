import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TrianguloComponent } from './triangulo/triangulo.component';
import { CuadradoComponent } from './cuadrado/cuadrado.component';
import { CirculoComponent } from './circulo/circulo.component';



@NgModule({
  declarations: [
    TrianguloComponent,
    CuadradoComponent,
    CirculoComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    TrianguloComponent,
    CuadradoComponent,
    CirculoComponent
  ]
})
export class FigurasModule { }
