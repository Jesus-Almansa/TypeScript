import { Component } from '@angular/core';

@Component({
  selector: 'app-triangulo',
  templateUrl: './triangulo.component.html',
  styleUrl: './triangulo.component.css'
})
export class TrianguloComponent {

}
