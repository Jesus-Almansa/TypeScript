import { Component } from '@angular/core';

@Component({
  selector: 'app-circulo',
  templateUrl: './circulo.component.html',
  styleUrl: './circulo.component.css'
})
export class CirculoComponent {

}
