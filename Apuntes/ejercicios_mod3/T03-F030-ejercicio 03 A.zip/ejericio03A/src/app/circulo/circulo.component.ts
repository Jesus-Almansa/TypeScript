import { Component } from '@angular/core';
import { TrianguloComponent } from '../triangulo/triangulo.component';

@Component({
  selector: 'figura-circulo',
  standalone: true,
  imports: [TrianguloComponent],
  templateUrl: './circulo.component.html',
  styleUrl: './circulo.component.css'
})
export class CirculoComponent {

}
