import { Injectable } from '@angular/core';
import { Producto } from './models/producto';

@Injectable({
  providedIn: 'root'
})
export class DatosService {

  private productos:Producto[];

  /* En un caso real el servicio no se inventa los datos ni los corta a partir de un array preexistente. Todo serían
  llamadas a un servidor.*/

  constructor() { 
    this.productos=[
      new Producto('R12XD','Sed vitae','Nunc sed tellus egestas malesuada vel at erat', 23, Date.parse('2011-12-23')),
      new Producto('F89SD','Donec ornare','Mi egestas mollis aliquam, metus odio facilisis arcu ut rhoncus sapien nisi id mauris', 23.32, Date.parse('2003-1-8')),
      new Producto('G78DS','Nulla id iaculis','Tortor Donec id condimentum purus. Curabitur sit amet convallis felis', 119, Date.parse('2014-7-10')),
      new Producto('K72SF',' Mauris','Interdum nec nunc et mollis', 94.5, Date.parse('2019-11-5')),
      new Producto('L23FG','Orci varius natoque','Penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 12, Date.parse('2007-9-1')),
      new Producto('M87GD','Suspendisse','Dignissim orci est at vulputate nisl condimentum non. Vestibulum et enim sapien', 42, Date.parse('2001-11-29')),
      new Producto('Y73BD','Suspendisse rhoncus','Semper turpis, eget sagittis ante dictum id nullam venenatis varius risus eget laoreet', 17.98, Date.parse('2013-8-19'))
    ];
  }

  public leerTodosLosProductos() {
    return this.productos;
  }

  public leerProductosPaginados(numPagina:number, tamPagina:number) {
    return this.productos.slice(numPagina*tamPagina,numPagina*tamPagina +  tamPagina);
  }
}
