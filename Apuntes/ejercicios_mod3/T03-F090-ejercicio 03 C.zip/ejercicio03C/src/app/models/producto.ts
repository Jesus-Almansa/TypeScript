export class Producto {
    constructor(
        public referencia:string,
        public nombre:string,
        public descripcion:string,
        public precio:number,
        public fechaFabricacion:number
    ){}
}