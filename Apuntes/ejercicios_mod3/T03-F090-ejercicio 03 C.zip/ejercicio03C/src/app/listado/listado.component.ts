import { Component } from '@angular/core';
import { DatosService } from '../datos.service';
import { Producto } from '../models/producto';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-listado',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './listado.component.html',
  styleUrl: './listado.component.css',
  providers:[DatosService]
})
export class ListadoComponent {
  lista:Producto[]=[];
  numPagina=0;
  tamPagina=3;

  constructor(private datos:DatosService) {
  }

  ngOnInit() {
    this.lista=this.datos.leerProductosPaginados(this.numPagina,this.tamPagina);
  }

  cambio(nuevo:number) {
    let listaLeida=this.datos.leerProductosPaginados(this.numPagina+nuevo, this.tamPagina);
    if (listaLeida.length!=0) {
      this.numPagina+=nuevo;
      this.lista=listaLeida;
    }
  }
}
